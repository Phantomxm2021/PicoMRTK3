// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Microsoft.MixedReality.OpenXR.Internal.Editor")]

[assembly: AssemblyVersion("1.6.0")]

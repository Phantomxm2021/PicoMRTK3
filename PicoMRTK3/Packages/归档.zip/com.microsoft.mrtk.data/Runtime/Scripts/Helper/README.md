﻿# Helper folder

The classes in this folder provide various miscellaneous services to other classes. They themselves are not concrete implementations of the public interfaces provided for this data framework.
﻿# Interfaces

The C# interfaces in this folder define all of the allowed communication between objects.  This ensures maximum flexibility for combining concepts in new combinations through dependency injection.

See each interface for more information.

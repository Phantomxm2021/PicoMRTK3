// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Collections;
using UnityEngine.TestTools;

namespace Microsoft.MixedReality.Toolkit.Performance.Tests
{
    public class SmokeTest
    {
        [UnityTest]
        public IEnumerator PerformancePackageTest()
        {
            yield return null;
        }
    }
}


// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Collections;
using UnityEngine.TestTools;

namespace Microsoft.MixedReality.Toolkit.Input.Tests.EditMode
{
    public class SmokeTest
    {
        [UnityTest]
        public IEnumerator InputPackageTest()
        {
            yield return null;
        }
    }
}

